<?php
require __DIR__ . '/../app/bootstrap.php';
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
function view($name,$vars=[]){ extract($vars); include __DIR__.'/../views/header.php'; include __DIR__.'/../views/'.$name.'.php'; include __DIR__.'/../views/footer.php'; }
if ($uri==='/' || $uri==='/index.php') { view('home'); exit; }
if ($uri==='/dashboard') { view('dashboard'); exit; }
http_response_code(404); echo "404 Not Found";