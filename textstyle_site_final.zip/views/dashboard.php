<section class="card">
  <h2>Личный кабинет</h2>
  <div class="grid2">
    <div>
      <label>Ваш Telegram ID
        <input id="tid" placeholder="например, 12345678">
      </label>
      <button class="btn" id="saveTid">Сохранить</button>
    </div>
    <div>
      <button class="btn" id="genRef">Получить реферальную ссылку</button>
      <input id="refLink" readonly placeholder="ссылка появится здесь">
    </div>
  </div>
</section>
<section class="card">
  <h3>Оставить отзыв</h3>
  <form id="reviewForm" class="grid1">
    <input name="user_id" id="rv_uid" placeholder="Telegram ID">
    <input name="user_name" placeholder="Имя (как показывать)">
    <input name="user_photo" placeholder="URL фото (необязательно)">
    <label>Оценка (1–5) <input type="number" name="rating" min="1" max="5" value="5"></label>
    <textarea name="review_text" placeholder="Ваш отзыв..."></textarea>
    <label><input type="checkbox" name="is_public" checked> Публично</label>
    <button class="btn">Отправить</button>
  </form>
</section>
<section class="card">
  <h3>Оплата</h3>
  <div class="grid2">
    <a class="btn" href="https://t.me/TextStyle_main_bot?start=prt_TKGJLsybBsI4Hq8w">STANDARD</a>
    <a class="btn" href="https://t.me/TextStyle_main_bot?start=prt_GiGtAMOsvYTBgC8X">PRO</a>
  </div>
  <p class="muted">После оплаты доступ выдаётся в группу Toolsy, бот сверяет подписку через Airtable.</p>
</section>
<script src="/assets/js/lk.js"></script>