<section class="hero card">
  <h1>TextStyle</h1>
  <p>Быстрые тексты. Умный Telegram-бот.</p>
  <div class="cta"><a class="btn" href="https://t.me/TextStyle_main_bot">Открыть @TextStyle_main_bot</a></div>
</section>
<section class="card">
  <h2>Калькулятор экономии времени</h2>
  <?php include __DIR__.'/partials/calculator_phone.php'; ?>
</section>
<section class="card">
  <h2>Реферальная программа</h2>
  <div class="ref-compact">
    <p>+7 дней за регистрацию друга и +7 за его оплату. Ваша ссылка в ЛК.</p>
    <a class="btn" href="/dashboard">Перейти в ЛК</a>
  </div>
</section>