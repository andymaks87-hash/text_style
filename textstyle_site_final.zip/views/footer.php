</main>
<footer class="ft"><div class="wrap">© 2025 TextStyle • ИП Смирнова А.А. • <a href="/offer.pdf">Договор-оферта</a> • <a href="/disclaimer.html">Отказ от обязательств</a></div></footer>
<script>
(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};m[i].l=1*new Date();
k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)
})(window, document,'script','https://mc.yandex.ru/metrika/tag.js?id='+ (<?=json_encode(env('YANDEX_METRIKA_ID'))?>||'104859506'), 'ym');
ym(<?=json_encode(env('YANDEX_METRIKA_ID'))?>||104859506, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", accurateTrackBounce:true, trackLinks:true});
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/104859506" style="position:absolute; left:-9999px;" alt=""/></div></noscript>
</body></html>