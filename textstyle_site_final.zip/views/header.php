<!doctype html><html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>TextStyle</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head><body>
<header class="nav"><div class="wrap"><a href="/">TextStyle</a><nav><a href="/dashboard">Личный кабинет</a></nav></div></header>
<main class="wrap">