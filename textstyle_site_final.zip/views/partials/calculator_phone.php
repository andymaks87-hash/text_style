<div class="phone">
  <div class="phone-screen">
    <div id="calcRows"></div>
    <template id="rowTpl">
      <div class="row" data-row>
        <input data-qty type="number" min="0" step="1" placeholder="Кол-во">
        <input data-time type="number" min="0" step="0.25" placeholder="Часов/ед.">
        <button type="button" class="btn btn-mini" data-del>×</button>
      </div>
    </template>
    <div class="actions">
      <button type="button" class="btn" data-add>Добавить</button>
      <button type="button" class="btn" data-copy>Копировать итог</button>
    </div>
    <div class="summary">
      <div>Итого часов: <b id="sumH">0.00</b></div>
      <div>Итого (чч:мм:сс): <b id="sumHMS">00:00:00</b></div>
    </div>
  </div>
</div>
<script>
(function(){
  function hms(h){const t=Math.round(h*3600),H=Math.floor(t/3600),M=Math.floor(t%3600/60),S=t%60;return [H,M,S].map(v=>String(v).padStart(2,'0')).join(':');}
  function recalc(){let total=0;document.querySelectorAll('[data-row]').forEach(r=>{const q=parseFloat(r.querySelector('[data-qty]').value||'0');const tm=parseFloat(r.querySelector('[data-time]').value||'0');total+=q*tm;});document.getElementById('sumH').textContent=total.toFixed(2);document.getElementById('sumHMS').textContent=hms(total);}
  function add(){const t=document.getElementById('rowTpl').content.cloneNode(true);document.getElementById('calcRows').appendChild(t);}
  document.addEventListener('input',e=>{if(e.target.matches('[data-qty],[data-time]'))recalc();});
  document.addEventListener('click',e=>{if(e.target.matches('[data-add]')){add();recalc();} if(e.target.matches('[data-del]')){e.target.closest('[data-row]').remove();recalc();} if(e.target.matches('[data-copy]')){navigator.clipboard.writeText('Часы: '+document.getElementById('sumH').textContent+' / '+document.getElementById('sumHMS').textContent);} });
  add();recalc();
})();
</script>