<?php
function airtable_request($method,$path,$body=null,$params=[]){
  $base = env('AIRTABLE_BASE_ID'); $api = env('AIRTABLE_API_KEY');
  $url = "https://api.airtable.com/v0/{$base}/".rawurlencode($path);
  if($params){ $url .= '?'.http_build_query($params); }
  $ch=curl_init($url);
  $headers=["Authorization: Bearer {$api}", "Content-Type: application/json"];
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers]);
  if($body!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body,JSON_UNESCAPED_UNICODE));
  $resp=curl_exec($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=$resp===false?curl_error($ch):null; curl_close($ch);
  return [json_decode($resp,true),$code,$err];
}
function at_create($table,$fields){ return airtable_request('POST',$table,['fields'=>$fields]); }
function at_list($table,$filter=null,$max=50){ $p=[]; if($filter) $p['filterByFormula']=$filter; $p['maxRecords']=$max; return airtable_request('GET',$table,null,$p); }
function at_update_first($table,$filter,$fields){
  [$d,$c,$e]=at_list($table,$filter,1); if(!$d||empty($d['records'])) return [null,404,'not_found'];
  $id=$d['records'][0]['id']; return airtable_request('PATCH', $table."/".$id, ['fields'=>$fields]);
}