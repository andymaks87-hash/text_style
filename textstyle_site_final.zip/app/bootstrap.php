<?php
date_default_timezone_set('UTC');
function env_load(){ static $cfg=null; if($cfg!==null) return $cfg; $file = __DIR__ . '/../.env.php'; if(!file_exists($file)) $file = __DIR__ . '/../.env.example.php'; $cfg = require $file; return $cfg; }
function env($k,$def=null){ $c=env_load(); return $c[$k] ?? $def; }
function log_info($tag,$data){ @file_put_contents(env('LOG_FILE'), '['.date('c')."] {$tag} ".json_encode($data,JSON_UNESCAPED_UNICODE).PHP_EOL, FILE_APPEND); }
function read_json_body(){ $raw=file_get_contents('php://input')?:''; $js=json_decode($raw,true); if(is_array($js)) return $js; return $_POST?:[]; }
function respond($arr,$code=200){ http_response_code($code); header('Content-Type: application/json; charset=utf-8'); echo json_encode($arr,JSON_UNESCAPED_UNICODE); exit; }
require __DIR__.'/airtable.php';