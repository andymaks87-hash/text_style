<?php
require __DIR__.'/../app/bootstrap.php';
$in = read_json_body(); $uid=$in['user_id']??''; $rating=intval($in['rating']??0); $text=trim($in['review_text']??'');
if(!$uid || !$rating || !$text){ respond(['ok'=>false,'error'=>'bad_request'],400); }
$fields = ['user_id'=>$uid,'user_name'=>$in['user_name']??'','user_photo'=>$in['user_photo']??'','rating'=>$rating,'review_text'=>$text,'is_public'=>!empty($in['is_public'])];
[$d,$c,$e]=at_create(env('AIRTABLE_TABLE_REVIEWS'),$fields);
if($c>=200 && $c<300) respond(['ok'=>true]); respond(['ok'=>false,'error'=>'airtable_error','detail'=>$d],500);