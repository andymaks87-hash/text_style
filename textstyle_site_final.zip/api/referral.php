<?php
require __DIR__.'/../app/bootstrap.php';
$uid = $_GET['user_id'] ?? ''; if(!$uid) respond(['ok'=>false,'error'=>'user_id_required'],400);
$base = rtrim(env('REF_BASE_URL'),'/'); $code = rtrim(strtr(base64_encode($uid), '+/', '-_'), '=');
$link = $base.'?ref='+$code; respond(['ok'=>true,'link'=>$link]);