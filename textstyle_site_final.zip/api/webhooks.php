<?php
require __DIR__.'/../app/bootstrap.php';
$raw=file_get_contents('php://input')?:''; $evt=json_decode($raw,true)?:[]; log_info('toolsy_webhook',$evt);
$type=$evt['type']??''; $d=$evt['data']??[];
if(in_array($type,['payment.completed','subscription.created','subscription.renewed'])){
  at_create(env('AIRTABLE_TABLE_PAYMENTS'), [
    'user_id'        => $d['user_id'] ?? '',
    'plan'           => $d['plan_code'] ?? '',
    'amount'         => floatval($d['amount'] ?? 0),
    'status'         => 'completed',
    'product_id'     => $d['product_id'] ?? '',
    'payment_method' => 'Toolsy',
    'paid_till'      => $d['paid_till'] ?? null
  ]);
  if(!empty($d['user_id']) && !empty($d['paid_till'])){
    at_update_first(env('AIRTABLE_TABLE_USERS'), "({telegram_id} = '{$d['user_id']}')", ['paid_till'=>$d['paid_till']]);
  }
}
respond(['ok'=>true]);