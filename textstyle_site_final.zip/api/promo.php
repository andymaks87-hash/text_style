<?php
require __DIR__.'/../app/bootstrap.php';
$in = read_json_body(); $code=strtoupper(trim($in['code']??'')); $uid=$in['user_id']??'';
if(!$code||!$uid) respond(['ok'=>false,'error'=>'bad_request'],400);
[$d,$c,$e]=at_list(env('AIRTABLE_TABLE_PROMOS'), "({code} = '{$code}')",1);
if(!$d || empty($d['records'])) respond(['ok'=>false,'error'=>'invalid_code'],404);
$pr=$d['records'][0]['fields']; if(empty($pr['active'])) respond(['ok'=>false,'error'=>'inactive'],400);
$disc=intval($pr['discount'] ?? 0); $bonus=intval($pr['bonus_days'] ?? 0);
at_create(env('AIRTABLE_TABLE_PROMO_USAGE'), ['user_id'=>$uid,'promo_code'=>$code,'discount'=>$disc,'bonus_days'=>$bonus]);
respond(['ok'=>true,'discount'=>$disc,'bonus_days'=>$bonus]);