<?php
return [
  'APP_ENV' => 'prod',
  'APP_DEBUG' => false,
  'APP_URL' => 'https://your-domain.tld',
  'AIRTABLE_API_KEY' => 'pat_xxxxxxxxxxxxxxxxxxxx',
  'AIRTABLE_BASE_ID' => 'appXXXXXXXXXXXXXX',
  'AIRTABLE_TABLE_USERS' => 'Users',
  'AIRTABLE_TABLE_PAYMENTS' => 'Payments',
  'AIRTABLE_TABLE_REVIEWS' => 'Reviews',
  'AIRTABLE_TABLE_REFERRALS' => 'Referrals',
  'AIRTABLE_TABLE_PROMOS' => 'Promos',
  'AIRTABLE_TABLE_PROMO_USAGE' => 'PromoUsage',
  'TOOLSY_SECRET' => '',
  'TELEGRAM_BOT' => '@TextStyle_main_bot',
  'REF_BASE_URL' => 'https://your-domain.tld/?ref',
  'YANDEX_METRIKA_ID' => '104859506',
  'LOG_FILE' => __DIR__ . '/../logs/app.log',
];